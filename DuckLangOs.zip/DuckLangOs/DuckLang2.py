import pygame
import sys

# Initialize
pygame.init()
WIDTH, HEIGHT = 480, 360
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("TempleOS Style Duck")

# Colors
SKY = (100, 200, 255)
SAND = (255, 255, 150)
DUCK_BODY = (255, 255, 0)
DUCK_BEAK = (255, 150, 0)
DUCK_EYE = (0, 0, 0)

clock = pygame.time.Clock()

# Duck position & direction
duck_x = 0
duck_y = HEIGHT - 110
duck_speed = 2
facing_right = True

def draw_duck(x, y, facing_right=True):
    if facing_right:
        # Facing right
        pygame.draw.rect(screen, DUCK_BODY, (x, y, 40, 30))              # Body
        pygame.draw.rect(screen, DUCK_BODY, (x + 30, y - 20, 20, 20))    # Head
        pygame.draw.rect(screen, DUCK_BEAK, (x + 50, y - 10, 10, 5))     # Beak
        pygame.draw.rect(screen, DUCK_EYE, (x + 45, y - 15, 3, 3))       # Eye
    else:
        # Facing left (flip horizontally)
        pygame.draw.rect(screen, DUCK_BODY, (x + 20, y, 40, 30))         # Body
        pygame.draw.rect(screen, DUCK_BODY, (x, y - 20, 20, 20))         # Head
        pygame.draw.rect(screen, DUCK_BEAK, (x - 10, y - 10, 10, 5))     # Beak
        pygame.draw.rect(screen, DUCK_EYE, (x + 5, y - 15, 3, 3))        # Eye

def draw_scene():
    screen.fill(SKY)
    pygame.draw.rect(screen, SAND, (0, HEIGHT - 80, WIDTH, 80))
    draw_duck(duck_x, duck_y, facing_right)

    font = pygame.font.SysFont("courier", 16)
    text = font.render("DuckLang", True, (0, 0, 0))
    screen.blit(text, (100, 20))

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    duck_x += duck_speed

    # Bounce at edges
    if duck_x + 60 > WIDTH or duck_x < 0:
        duck_speed *= -1
        facing_right = duck_speed > 0  # Flip direction

    draw_scene()
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()